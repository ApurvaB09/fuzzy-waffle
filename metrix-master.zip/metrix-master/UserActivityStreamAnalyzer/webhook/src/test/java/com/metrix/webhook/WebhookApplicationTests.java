//package com.metrix.webhook;
//
//import com.metrix.webhook.controller.WebHookController;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.TestPropertySource;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//import static org.assertj.core.api.Assertions.assertThat;
//
//@ExtendWith(SpringExtension.class)
//@SpringBootTest(classes = WebhookApplication.class)
//@TestPropertySource("/application-test.properties")
//public class WebhookApplicationTests {
//
//    @Autowired
//    private WebHookController webHookController;
//
//    @Test
//    public void testController() throws Exception{
//        assertThat(webHookController).isNotNull();
//    }
//
//}

