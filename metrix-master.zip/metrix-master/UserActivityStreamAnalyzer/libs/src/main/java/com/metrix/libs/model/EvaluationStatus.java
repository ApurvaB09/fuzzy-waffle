package com.metrix.libs.model;

public enum EvaluationStatus {
    PASSED,
    PENDING,
    FAILED
}
