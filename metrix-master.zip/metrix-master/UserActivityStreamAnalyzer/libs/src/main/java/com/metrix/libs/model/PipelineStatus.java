package com.metrix.libs.model;

public enum PipelineStatus {
    ACTIVE, DRAFTED, SUSPENDED
}
