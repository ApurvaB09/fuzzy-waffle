package com.metrix.awardsmicroservice.libs.model;

public enum Status {
    ACTIVE, PENDING, BLOCKED
}
