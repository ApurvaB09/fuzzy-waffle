package com.metrix.awardsmicroservice.libs.model;

public enum EvaluationStatus {
    PASSED, PENDING, FAILED
}
