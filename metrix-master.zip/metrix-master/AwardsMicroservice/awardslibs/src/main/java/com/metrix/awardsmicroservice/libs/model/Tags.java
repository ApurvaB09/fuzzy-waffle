package com.metrix.awardsmicroservice.libs.model;

public class Tags {
    private String name;

    public Tags() {
    }

    public Tags(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}