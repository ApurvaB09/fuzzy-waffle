/**
 * Netflix Zuul API Gateway Server Test Class
 */

package com.metrix.apigatewayserver;

import com.google.common.annotations.VisibleForTesting;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ApiGatewayServerApplicationTests {

    /**
     *
     *
     * Test Method Netflix Zuul API Gateway Server
     */
    @VisibleForTesting
    void contextLoads() {
    }

}
