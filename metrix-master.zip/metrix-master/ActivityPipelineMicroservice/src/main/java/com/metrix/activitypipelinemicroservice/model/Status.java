package com.metrix.activitypipelinemicroservice.model;

public enum Status {
    ACTIVE, PENDING, BLOCKED
}
