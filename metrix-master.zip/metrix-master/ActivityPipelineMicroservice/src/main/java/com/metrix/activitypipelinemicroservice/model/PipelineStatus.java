package com.metrix.activitypipelinemicroservice.model;

public enum PipelineStatus {
    ACTIVE, DRAFTED, SUSPENDED
}
