/**
 * Web Application Microservice Test Class
 */

package com.metrix.webappmicroservice;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class WebAppMicroserviceApplicationTests {

    /**
     *
     *
     * Test Method for Web Application Test Class
     */
    @Test
    public void contextLoads() {
    }

}
